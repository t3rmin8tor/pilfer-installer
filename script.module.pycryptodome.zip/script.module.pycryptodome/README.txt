Add the following to your addon.xml between the "requires" tags:

<import addon="script.module.pycryptodome" version="1.0.0"/>